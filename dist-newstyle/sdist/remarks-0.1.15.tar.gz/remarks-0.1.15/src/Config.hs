module Config where

indentation :: String
indentation = "  "

judgementMarker :: Char
judgementMarker = '#'
