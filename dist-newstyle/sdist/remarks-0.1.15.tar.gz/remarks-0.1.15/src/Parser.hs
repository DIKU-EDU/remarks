module Parser
  ( ParseError
  , parseString
  , parseFile
  ) where

import Parser.ImplParsec
-- import Parser.Impl
  ( ParseError
  , parseString
  , parseFile
  )
